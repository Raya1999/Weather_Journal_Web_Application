// Global Variables
const apiKey = '06be3976f36c3616e126ab0401b3e3b8';

// Event listener for the "Generate" button
document.getElementById('generate').addEventListener('click', performAction);

// Function to handle the "Generate" button click
function performAction() {
    const zipCode = document.getElementById('zip').value;
    const feelings = document.getElementById('feelings').value;

    getWeatherData(zipCode)
        .then(function (data) {
            // Update the UI with weather data and user feelings
            updateUI(data, feelings);
        })
        .catch(function (error) {
            console.error('Error fetching weather data:', error);
        });
}

// Function to fetch weather data from OpenWeatherMap API
async function getWeatherData(zipCode) {
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?zip=${zipCode}&appid=${apiKey}&units=metric`;
    
    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        return data;
    } catch (error) {
        throw error;
    }
}

// Function to update the UI with weather data and feelings
function updateUI(weatherData, feelings) {
    document.getElementById('date').textContent = newDate;
    document.getElementById('temp').textContent = `Temperature: ${weatherData.main.temp}°C`;
    document.getElementById('content').textContent = `Feeling: ${feelings}`;
}