// Require Express to run server and routes
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

// Start up an instance of app
const app = express();

/* Middleware */
// Configure cors to allow cross-origin requests
app.use(cors());

// Configure bodyParser to handle request data
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Initialize the main project folder
app.use(express.static('website'));

// Setup Server
const port = 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

// Routes
// Create a route to handle incoming data
app.post('/addData', (req, res) => {
    const newData = req.body;
    projectData = newData;
    res.send({ message: 'Data received successfully' });
});

// Create a route to send project data to the client
app.get('/getData', (req, res) => {
    res.send(projectData);
});
